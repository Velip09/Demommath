import numpy as np

def add_num(u,v):
      return np.sum([u, v], axis=0)

