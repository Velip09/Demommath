def find_mean(num):
    # Calculate the mean
    total_sum = sum(num)  # Add all numbers using the sum() function
    mean = total_sum / len(num)  # Divide the sum by the number of elements

    return mean


