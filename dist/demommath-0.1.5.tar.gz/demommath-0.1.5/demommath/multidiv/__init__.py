from .md import multiply
from .md import divide