import numpy as np
from .addarray import add_num
