from .fact import factorial
