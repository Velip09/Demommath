def is_odd_or_even(number):
    if number % 2 == 0:
        return "Even"
    else:
        return "Odd"
