# demmomath

A simple Python package for basic mathematical operations.

## Installation

```bash
pip install demommath

Usage

from demommath import operations

result = operations.add(2, 3)
print(result)

##adding array

# Example arrays
array_a = [1, 2, 3, 4]
array_b = [5, 6, 7, 8]

# Perform array addition
result_array = add_arrays(array_a, array_b)

# Display the result
print("Array A:", array_a)
print("Array B:", array_b)
print("Result Array:", result_array)
